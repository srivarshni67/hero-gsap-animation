import { useEffect, useRef } from "react";
import gsap from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";

gsap.registerPlugin(ScrollTrigger);

export default function Home() {
  const headlineRef = useRef(null);
  const statsRef = useRef([]);
  const imageRef = useRef(null);

  useEffect(() => {
    gsap.fromTo(headlineRef.current,{ opacity: 0, y: 50 },{ opacity: 1, y: 0, duration: 1.2 });

    gsap.fromTo(statsRef.current,{ opacity: 0, y: 30 },{
      opacity: 1,
      y: 0,
      stagger: 0.3,
      duration: 0.8,
      delay: 0.5,
    });

    gsap.to(imageRef.current,{
      y: -150,
      scale: 1.1,
      scrollTrigger:{
        trigger: imageRef.current,
        start: "top center",
        end: "bottom top",
        scrub: true,
      }
    });
  }, []);

  return (
    <div className="bg-black text-white min-h-screen flex flex-col items-center justify-center">
      <h1 ref={headlineRef} className="text-4xl tracking-[0.6em] mb-10">
        W E L C O M E I T Z F I Z Z
      </h1>

      <div className="flex gap-10">
        {["95%","120+","10x"].map((val,i)=>(
          <div key={i} ref={el => statsRef.current[i]=el}>
            <h2>{val}</h2>
          </div>
        ))}
      </div>

      <img ref={imageRef} src="https://images.unsplash.com/photo-1522199710521-72d69614c702" className="mt-10 w-72"/>
    </div>
  );
}
