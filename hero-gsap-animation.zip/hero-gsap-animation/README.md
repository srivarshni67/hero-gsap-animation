# Hero GSAP Animation

Modern hero section with GSAP scroll animations using Next.js.

## Features
- Smooth intro animation
- Staggered stats
- Scroll animation

## Run
npm install
npm run dev
